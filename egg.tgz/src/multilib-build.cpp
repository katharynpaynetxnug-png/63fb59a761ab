// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("multilib build"); }
int main(){
  announce();
  return lionss_run_workload("multilib-build");
}
