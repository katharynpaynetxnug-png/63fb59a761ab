// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("gitleaks\n", stdout);
  return lionss_run_workload("gitleaks");
}
