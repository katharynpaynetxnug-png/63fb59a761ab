// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("serialization tests"); }
int main(){
  announce();
  return lionss_run_workload("serialization-tests");
}
