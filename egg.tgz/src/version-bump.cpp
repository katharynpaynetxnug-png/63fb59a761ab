// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("version bump\n", stdout);
  return lionss_run_workload("version-bump");
}
