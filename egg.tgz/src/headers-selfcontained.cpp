// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("headers selfcontained\n", stdout);
  return lionss_run_workload("headers-selfcontained");
}
